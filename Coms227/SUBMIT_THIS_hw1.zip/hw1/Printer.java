package hw1;

import java.lang.Math;



public class Printer {

	/**

	 * Stores the number of sheets in tray when the sheetsAvailble is set to 0

	 */

	private int sheetsTray=0;

	/**

	 * Stores the page after which the next page value will be set to 0 again 

	 */

	private int spec=0;

	/**

	 * tells us the tray capacity

	 */

	private int trayCap=0;

	/**

	 *  gives us the sheets which still have to be printed

	 */

	private int sheetsAvailable=0; 

	/**

	 * gives us the page number which is currently going to be printed

	 */

	private int printingPage=0; 

	/**

	 * gives us the total number of pages which have been printed 

	 */

	private int pagesPrinted=0; 

	

	/**

	 * defining the constructor 

	 * @param trayCapacity

	 * sets instance variable trayCap to trayCapacity given by the user 

	 */

	public Printer(int trayCapacity) {

		trayCap = trayCapacity;



	}

	

	/**

	 * @param documentPages

	 * updates pages printed value with document pages

	 * changes current printing page to 0

	 * reduces the sheetsAvailable instance variable by documentPages

	 */

	public void startPrintJob(int documentPages) {

		spec= documentPages;

		printingPage = 0;

	}

	

	/**

	 * @return sheetsAvailable

	 * gives us the sheets remaining which we can print

	 */

	public int getSheetsAvailable() {

		return sheetsAvailable;

		}

	

	 /**

	  * @return printingPage

	  * gives us the current page being printed

	  * uses the variable spec to upat

	  */

	public int getNextPage() {

		return printingPage%spec;

		

	}

	/**

	 * 

	 * @return pagesPrinted

	 * gives us the total number of pages which have been printed 

	 */

	public int getTotalPages() {

		return pagesPrinted;

	}

	

	/**

	 * Prints a page if there are sheets available.

	 * makes a temperory variable temp1 which stores the maximum value between sheetsAvailable and 0.

	 * if there are no sheets 0 is taken as max and if there are sheets temp1 stores the value of sheetsAvailable.

	 * temp2 then stores 0 if temp1 value was 0 , and temp2 stores 1 if temp1 value was set to sheetsavailable.

	 * then temp2 values updates sheetsAvailable,printingPage and pagesPrinted values accordingly.

	 */

	public void printPage() {

		int temp1 = Math.max(sheetsAvailable,0);

		int temp2 = Math.min(temp1,1);

		sheetsAvailable-=temp2;

		printingPage+=temp2;

		pagesPrinted+=temp2;

		printingPage= printingPage%spec;

		

		}

	/**

	 * Assigns the value of sheetsavailable to sheetsinTray

	 * makes the available sheets in tray 0

	 */

	public void removeTray() {

		sheetsTray=sheetsAvailable;

		sheetsAvailable = 0;

		

	}

	/**

	 *  makes the available sheets in tray equal to max capacity of tray 

	 */

	public void replaceTray() {

		sheetsAvailable = sheetsTray;

	}

	

	/**

	 * @param sheets

	 * specified sheets are added to sheetsAvailbale

	 * if sheetsAvailable crosses trayCap then sheetsAvailable is set to trayCap

	 */

	public void addPaper(int sheets) {

		sheetsTray+= sheets;

		sheetsAvailable = sheetsTray;

		sheetsAvailable=Math.min(sheetsAvailable,trayCap);	

	}

	

	/**

	 * 

	 * @param sheets

	 * removes number of sheets from available sheets

	 * if sheetsAvaialble goes below 0 it is set to 0 

	 */

	public void removePaper(int sheets) {

		sheetsTray-=sheets;

		sheetsAvailable=sheetsTray;

		sheetsAvailable = Math.max(0,sheetsAvailable);

		}

	

	

	

	}

