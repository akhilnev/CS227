package hw2;

public class CyGame {
	/**@author akhileshnevatia
	 * Do nothing square type.
	 */
	public static final int DO_NOTHING = 0;
	/**
	 * Pass go square type.
	 */
	public static final int PASS_GO = 1;
	/**
	 * Cyclone square type.
	 */
	public static final int CYCLONE = 2;
	/**
	 * Pay the other player square type.
	 */
	public static final int PAY_PLAYER = 3;
	/**
	 * Get an extra turn square type.
	 */
	public static final int EXTRA_TURN = 4;
	/**
	 * Jump forward square type.
	 */
	public static final int JUMP_FORWARD = 5;
	/**
	 * Stuck square type.
	 */
	public static final int STUCK = 6;
	/**
	 * Points awarded when landing on or passing over go.
	 */
	public static final int PASS_GO_PRIZE = 200;
	/**
	 * The amount payed to the other player per unit when landing on a
	 * PAY_PLAYER square.
	 */
	public static final int PAYMENT_PER_UNIT = 20;
	/**
	 * The amount of money required to win.
	 */
	public static final int MONEY_TO_WIN = 400;
	/**
	 * The cost of one unit.
	 */
	public static final int UNIT_COST = 50;
	
	/**
	 * stores the number of squares on game board
	 */
	private int numSquares;
	/**
	 * Stores the Player 1 position and updates it accordingly
	 */
	private int P1position =0;
	/**
	 * Stores the Player 2 position and updates it accordingly
	 */
	private int P2position=0;
	/**
	 * Stores the number of units player 1 buys , starting with 1
	 */
	private int Player1units = 1;
	/**
	 * Stores the number of units player 2 buys , starting with 1
	 */
	private int Player2units=1;
	/**
	 * Variable stores who the currentplayer is starting from player 1
	 */
	private int currentPlayer = 1;
	/**
	 * Stores the amount of money Player 1 has
	 */
	private int Player1Money;
	/**
	 * Stores the amount of money Player 2 has
	 */
	private int Player2Money;
	/**
	 * @param  numSquares
	 * @param  startingMoney
	 * Sets constructor and also sets starting money everytime new GAME IS created
	 */
	public CyGame(int numSquares, int startingMoney) 
	   {
		this.numSquares= numSquares;
		Player1Money = startingMoney;
		Player2Money = startingMoney;
		
		}
	/**
	 * @return currentPlayer 
	 */
	
	public int getCurrentPlayer() {
		return currentPlayer;
	}
	/**
	 * @return P1position
	 * Returns Player 1 position
	 */
	public int getPlayer1Square() {
		return this.P1position;
	}
	/**
	 * @return P2position
	 * Returns Player 2 position
	 */
	
	public int getPlayer2Square() {
		return this.P2position;
	}
	/**
	 * @return Player1units
	 * Returns the number of units player 1 has purchased
	 */
	
	public int getPlayer1Units() {
		return Player1units;
	}
	/**
	 * @return Player2units
	 * Returns the number of units player 2 has purchased
	 */
	public int getPlayer2Units() {
		return Player2units;
	}
	
	/**
	 * 
	 * @param Square
	 * @return what the role of the square the player lands on is 
	 * We call this method everytime we roll the die for both players to check what he needs to do based on where he landed  
	 * We do this by giving the current square the player is on as an input in the method
	 */
	public int getSquareType(int Square) {
	
		if( Square == 0) {
			return PASS_GO;
		}else if (Square == numSquares-1 ) {
			return  CYCLONE;
		}else if (Square%5==0) {
			return PAY_PLAYER ;
		}else if ( Square%7==0 || Square%11==0) {
			return EXTRA_TURN;
		}else if(Square%3==0) {
			return STUCK;
		}else if ( Square%2==0) {
			return JUMP_FORWARD;
		}else {
			return DO_NOTHING;
		}
	}
	

	/**
	 * Everytime the player lands on a square which is classified as do nothing he has an option to buy unit 
	 * This method increase the number of purchased units by 1 and accordingly decreases the money player has 
	 * This only happens if player has enough funds to buy a unit andthe game is not ended
	 * If player chooses to buy unit his turn is ended
	 */
	public void buyUnit() 
	{
		int x = getCurrentPlayer();
		if ((x==1)&&(Player1Money>=UNIT_COST)&&(isGameEnded()==false)&&getSquareType(P1position) == DO_NOTHING)
		{
			Player1units+=1;
			Player1Money-=UNIT_COST ;
			
		}
		else if ((x==2)&&(Player2Money>=UNIT_COST)&&(isGameEnded()==false)&& getSquareType(P2position) == DO_NOTHING){
			Player2units+=1;
			Player2Money-=UNIT_COST ;
			
		}else {
			endTurn();
		}
		endTurn();
	}
	/**
	 * On callig this method player can sell his unit to get money 
	 * This only happens if he has atleast 1 unit to sell and game is not ended 
	 * On selling unit player turn is ended 
	 */
	public void sellUnit() 
	{
		int x = getCurrentPlayer();
		if ((x==1) && (Player1units>=1) && ( isGameEnded()==false))
			{
			Player1units-=1;
			Player1Money+=UNIT_COST ;
			
			}
		else if((x==2) && (Player2units>=1)&& ( isGameEnded()==false)) 
		{
			Player2units-=1;
			Player2Money+=UNIT_COST ;
			
			
		}else {
			endTurn();
		}
		
		endTurn() ;
	}
	
	/**
	 *methods returns player 1 money
	 * @return Player1Money
	 */
	public int getPlayer1Money() {
		return Player1Money;
	}
	
	/**
	 *  methods returns player 2 money
	 * @return Player2Money
	 */
	public int getPlayer2Money() {
		return Player2Money;
	}
	
	/**
	 * When method is called value of currentPlayer is switched from 1 to 2 or 2 to 1.
	 */
	public void endTurn() {
		int x = getCurrentPlayer();
		if (x ==1) {
			currentPlayer=2;
		}else {
			currentPlayer=1;
		}
		
	}
	
	/** 
	 * Method checks conditions for game to end which is balance for any player becoming negative or crossing the money to win mark
	 * If any player satisfies one of those conditions true is returned else false is returned 
	 * @return true or false , based on whether the game is ended
	 */
	public boolean isGameEnded()
	{
		if ( Player1Money>=MONEY_TO_WIN || Player2Money>=MONEY_TO_WIN || Player1Money<0 || Player2Money<0 ) {
			return true;
		} else {
			return false;
		}
		
	}
	
	
	/**
	 * Returns a one-line string representation of the current game state. The
	 * format is:
	 * <p>
	 * <tt>Player 1*: (0, 0, $0) Player 2: (0, 0, $0)</tt>
	 * <p>
	 * The asterisks next to the player's name indicates which players turn it
	 * is. The numbers (0, 0, $0) indicate which square the player is on, how
	 * many units the player has, and how much money the player has
	 * respectively.
	 * 
	 * @return one-line string representation of the game state
	 */
	public String toString() {
	String fmt = "Player 1%s: (%d, %d, $%d) Player 2%s: (%d, %d, $%d)";
	String player1Turn = "";
	String player2Turn = "";
	if (getCurrentPlayer() == 1) {
	player1Turn = "*";
	} else {
	player2Turn = "*";
	}
	return String.format(fmt,
	player1Turn, getPlayer1Square(), getPlayer1Units(), 
	getPlayer1Money(),
	player2Turn, getPlayer2Square(), getPlayer2Units(), 
	getPlayer2Money());
	}
	
	/**
	 * @param value , adds value to the player position 
	 * if player is on stuck only moves forward if roll is an even number 
	 * if player not on stuck he moves aheadbas long as gameended is false
	 */

	public void roll(int value) {

		int x = getCurrentPlayer();
		if ((x ==1) && ( ( (getSquareType(P1position) == STUCK ) && value%2==0) || ( getSquareType(P1position) != STUCK ) ) &&(isGameEnded()==false) )
		{       
			    P1position += value;
			    /**
			     * We store the player position in b 
			     * Then we check to see if he has exceeded the number of squares using b Math.min function
			     * if the b option was not chosen in math.min that means the player had exceeded the number of squares on the board and started another round
			     * if the player starts another round we add PASS_GO_PRIZE to his money amount
			     */
			    int b = P1position;
			    P1position=Math.min(P1position%numSquares,b);
			    if (P1position!=b) {
			    	Player1Money+=PASS_GO_PRIZE;
			    }
			    /**
			     * If player lands on payplayer the player currently playing needs to pay money to the other player
			     * the amount of money is number of units the other player has multiplied by the Payment_per_unit
			     * we subtract this amount from currentplayer and add to the other player
			     */
				if (getSquareType(P1position)==	PAY_PLAYER) 
			    {
				int Money =  Player2units*PAYMENT_PER_UNIT;
				Player1Money-=Money;
				Player2Money+=Money;
				
			    }
				/**
				 * if player lands on extra turn the currently player remains the same , we do this by calling endturn() function twice
				 */
				else if(getSquareType(P1position)==EXTRA_TURN)
				{
			    	endTurn();
			    	
			    }
				/**
				 * if player lands on jumpforward he is advanced another 4 positions 
				 */
				else if(getSquareType(P1position)==JUMP_FORWARD) 
				{
					P1position += 4;
					 int temp = P1position;
					    P1position=Math.min(P1position%numSquares,temp);
					    if (P1position!=temp) {
					    	Player1Money+=PASS_GO_PRIZE;
					    }
					
				}
			/**
			 * if player lands on cyclone ( last position on board) he is taken to the position of the other player and no passgo money is added even if he passes 0 to do this
			 */
				else if(getSquareType(P1position)==CYCLONE) {
					P1position = P2position;
				}
			
			
		}
		/**
		 * The same code metioned above is repeated but for player 2 and with respect to player2 variables
		 */
		else if((x ==2) && ( ((getSquareType(P2position) == STUCK ) && value%2==0) || ( getSquareType(P2position) != STUCK ))&&(isGameEnded()==false))
		{ 
		    	P2position += value;
		    	
		    	int c = P2position;
				P2position=Math.min(P2position%numSquares,c);
				if (P2position!=c) {
				    	Player2Money+=PASS_GO_PRIZE;
				    }
			if (getSquareType(P2position)==	PAY_PLAYER) 
		    {
			int Money =  Player1units*PAYMENT_PER_UNIT;
			Player2Money-=Money;
			Player1Money+=Money;
			
		    }
			else if(getSquareType(P2position)==EXTRA_TURN)
			{
		    	endTurn();
		    	
		    }
			else if(getSquareType(P2position)==JUMP_FORWARD) 
			{
				P2position+=4;
				int temp2 = P2position;
				P2position=Math.min(P2position%numSquares,temp2);
				if (P2position!=temp2) {
				    	Player2Money+=PASS_GO_PRIZE;
				    }
					
			}
			else if(getSquareType(P2position)==CYCLONE) {
				P2position = P1position;
			}
		
			
	    }
		endTurn() ;
		
	}

	
}
