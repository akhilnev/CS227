package hw3;
/**
 * Main panel for the user interface of a Block Slider game.
 * 
 * @author Akhilesh Nevatia
 */

import static api.Direction.*;

import api.Direction;
import api.Orientation;


/**
 * Represents a block in the Block Slider game.
 */
public class Block {
	/*
	 * initializes this as final first row for a block used in reset
	 */
	private final int f_row;
	/*
	 *  initializes this as row which is updated as block is moved
	 */
	private int frow;
	/*
	 * initializes this as final first column for a block used in reset
	 */
	private final int f_col;
	/*
	 *  initializes this as column which is updated as block is moved
	 */
	private int fcol;
	/*
	 *  stores the length of the block
	 */
	private int len;
	/*
	 * stores the orientation of the block 
	 */
	private final Orientation ori; 
	
	

	/**
	 * Constructs a new Block with a specific location relative to the board. The
	 * upper/left most corner of the block is given as firstRow and firstCol. All
	 * blocks are only one cell wide. The length of the block is specified in cells.
	 * The block can either be horizontal or vertical on the board as specified by
	 * orientation.
	 * 
	 * @param firstRow    the first row that contains the block
	 * @param firstCol    the first column that contains the block
	 * @param length      block length in cells
	 * @param orientation either HORIZONTAL or VERTICAL
	 */
	public Block(int firstRow, int firstCol, int length, Orientation orientation) {//initializes all the private variables 
		f_row = firstRow;
		frow =  firstRow;
		fcol =  firstCol;
		len = length;
		ori = orientation;
		f_col = firstCol;
		
		
	}

	/**
	 * Resets the position of the block to the original firstRow and firstCol values
	 * that were passed to the constructor during initialization of the the block.
	 */
	public void reset() {
		frow = f_row;
		fcol = f_col;
		
	}

	/**
	 * Move the blocks position by one cell in the direction specified. The blocks
	 * first column and row should be updated. The method will only move VERTICAL
	 * blocks UP or DOWN and HORIZONTAL blocks RIGHT or LEFT. Invalid movements are
	 * ignored.
	 * 
	 * @param dir direction to move (UP, DOWN, RIGHT, or LEFT)
	 */
	public void move(Direction dir) {	
		if(ori == Orientation.HORIZONTAL) {
			if(dir==Direction.LEFT) {
				fcol-=1;
			}
			else if(dir==Direction.RIGHT) {
				fcol+=1;
				
			}
			
		}else if ( ori ==Orientation.VERTICAL) {
			if (dir==Direction.UP) {
				frow-=1;
			}else if (dir==Direction.DOWN){
				frow+=1;
		
			}
		}
		
	}

	/**
	 * Gets the first row of the block on the board.
	 * 
	 * @return first row
	 */
	public int getFirstRow() {
		return frow;
	}

	/**
	 * Sets the first row of the block on the board.
	 * 
	 * @param firstRow first row
	 */
	public void setFirstRow(int firstRow) {
		frow = firstRow;
	}

	/**
	 * Gets the first column of the block on the board.
	 * 
	 * @return first column
	 */
	public int getFirstCol() {
		// TODO
		return fcol;
	}

	/**
	 * Sets the first column of the block on the board.
	 * 
	 * @param firstCol first column
	 */
	public void setFirstCol(int firstCol) {
		fcol = firstCol;
	}

	/**
	 * Gets the length of the block.
	 * 
	 * @return length measured in cells
	 */
	public int getLength() {
		return len;
	}

	/**
	 * Gets the orientation of the block.
	 * 
	 * @return either VERTICAL or HORIZONTAL
	 */
	public Orientation getOrientation() {
		return ori;
	}

	@Override
	public String toString() {
		return "(row=" + getFirstRow() + ", col=" + getFirstCol() + ", len=" + getLength()
				+ ", ori=" + getOrientation() + ")";
	}
}
