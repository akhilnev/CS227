package hw3;
/**
 * Main panel for the user interface of a Block Slider game.
 * 
 * @author Akhilesh Nevatia
 */

import static api.Direction.*;
import static api.CellType.*;

import static api.Orientation.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import api.Cell;
import api.DescriptionUtil;
import api.Direction;
import api.Move;
import api.Orientation;

/*
	 
 * Represents a board in the Block Slider game. A board contains a 2D grid of
 * cells and a list of blocks that slide over the cells.
 */
public class Board {
	/*
	 * creates a test grid used in main for testcases
	 */
	private static String[][] testDescription1 = 
		{ { "*", "*", "*", "*", "*" }, 
		  { "*", ".", ".", ".", "*" }, 
		  { "*", "[", "]", ".", "e" }, 
		  { "*", ".", ".", ".", "*" }, 
		  { "*", ".", ".", ".", "*" }, 
		  { "*", "*", "*", "*", "*" } }; 
	
	/**
	 * 2D array of cells, the indexes signify (row, column) with (0, 0) representing
	 * the upper-left cornner of the board.
	 */
	private static Cell[][] grid ;
	
	/*
	 * makes a variable setting gameover to true which is later set to false if we want our isGameOver() method to return false
	 */
	private boolean gameover=true; 
	/*
	 * sets the block grabbed to false
	 */
	private boolean isblockg=false; 
	/*
	 *  stores the currently grabbed row for the grabbed block
	 */
	private int grabrow; 
	/*
	 *  stores the currently grabbed column for the grabbed block
	 */
	private int grabcolumn; 
	
	/*
	 * stores the grabbed block while moving 
	 */
	
	private Block block = null; 

	/**
	 * A list of blocks that are positioned on the board.
	 */
	private static ArrayList<Block> blocks = GridUtil.findBlocks(testDescription1); // stores the list of blocks and is later replaced based on the textfile passed in the game

	/**
	 * A list of moves that have been made in order to get to the current position
	 * of blocks on the board.
	 */
	private ArrayList<Move> moveHistory = new ArrayList<Move>();// stores the moveHistory of our block

	/**
	 * Constructs a new board from a given 2D array of cells and list of blocks. The
	 * cells of the grid should be updated to indicate which cells have blocks
	 * placed over them (i.e., setBlock() method of Cell). The move history should
	 * be initialized as empty.
	 * 
	 * @param grid   a 2D array of cells which is expected to be a rectangular shape
	 * @param blocks list of blocks already containing row-column position which
	 *               should be placed on the board
	 */
	public Board(Cell[][] gridd, ArrayList<Block> blocks) {
		Board.blocks = blocks;
		grid = new Cell[gridd.length][gridd[0].length];
		for( int i = 0 ; i < gridd.length ; i++) {
			
			grid[i] = gridd[i];
		}
		for(Block i : blocks) {//iterates through the blocks using foreach loop and sets block on out grid 
			int r = i.getFirstRow();
			int c = i.getFirstCol();
			int l = i.getLength();
			grid[r][c].setBlock(i);
			Orientation or = i.getOrientation();
			if (or==HORIZONTAL) {
			for( int j = 1 ; j < l ; j++) {
				grid[r][c+j].setBlock(i);
			}
			}else if ( or == VERTICAL) {
				for( int j = 1 ; j < l ; j++) {
					grid[r+j][c].setBlock(i);
				}
				
			}
			
				
			}
			moveHistory = new ArrayList<Move>();//reinitializes the move history 
		}
	

	
	/*
	 * Makes a 2D string representation of our current grid without the blocks which is later used in reset as a helper method when we want to rest our board
	 */
	private static String[][] isgmaker(Cell[][] x){ 
		String[][] arr = new String[x.length][x[0].length];
		for(int i = 0 ; i < x.length ; i ++) {
			for( int j = 0 ; j < x[i].length ; j ++) {
				if (x[i][j].isFloor() ) {
					arr[i][j] = ".";
			    }else if ( x[i][j].isExit()) {
			    	arr[i][j] = "e";
			    }else if (x[i][j].isWall()) {
			    	arr[i][j] = "*";
			    }
			}
		}
		return arr;
		
	}
	
	/**
	 * Constructs a new board from a given 2D array of String descriptions.
	 * <p>
	 * DO NOT MODIFY THIS CONSTRUCTOR
	 * 
	 * @param desc 2D array of descriptions
	 */
	
	public Board(String[][] desc) {
		this(GridUtil.createGrid(desc), GridUtil.findBlocks(desc));
		
	}

	/**
	 * Models the user grabbing a block over the given row and column. The purpose
	 * of grabbing a block is for the user to be able to drag the block to a new
	 * position, which is performed by calling moveGrabbedBlock(). This method
	 * records two things: the block that has been grabbed and the cell at which it
	 * was grabbed.
	 * 
	 * @param row row to grab the block from
	 * @param col column to grab the block from
	 */
	public void grabBlockAtCell(int row, int col) {
		grabrow = row;
		grabcolumn=col;
		for(Block i : blocks) {
			int r = i.getFirstRow();
			int c = i.getFirstCol();
			int l = i.getLength();
			Orientation or = i.getOrientation();
			int r_=r;
			int c_=c;
			if(or==HORIZONTAL) {
				for( int j = 0 ; j < l ; j++) {
					if(r_==row && c_+j==col) {
					block =i;
					isblockg=true;
					break;
				}
			}
				
			}
			else if (or == VERTICAL) {
				for( int j = 0 ; j < l ; j++) {
					if(r_+j==row && c_==col) {
						block =i;
						isblockg=true;
						break;
					}
				}
				}
		}
		
	}
	

	/**
	 * Set the currently grabbed block to null.
	 */
	public void releaseBlock() {
		block  = null;
		isblockg=false;
	}

	/**
	 * Returns the currently grabbed block.
	 * 
	 * @return the current block
	 */
	public Block getGrabbedBlock() {
		return block;
	}

	/**
	 * Returns the currently grabbed cell.
	 * 
	 * @return the current cell
	 */
	public Cell getGrabbedCell() {
		
		return grid[grabrow][grabcolumn];
	}

	/**
	 * Returns true if the cell at the given row and column is available for a block
	 * to be placed over it. Blocks can only be placed over floors and exits. A
	 * block cannot be placed over a cell that is occupied by another block.
	 * 
	 * @param row row location of the cell
	 * @param col column location of the cell
	 * @return true if the cell is available for a block, otherwise false
	 */
	//replace static
	public boolean canPlaceBlock(int row, int col) {//changed from static 
		
		if(!(grid[row][col].hasBlock())&&(grid[row][col].isFloor()||grid[row][col].isExit())) {
			return true;
		} else {
		    return false;
		   
		}
			
		
	}

	/**
	 * Returns the number of moves made so far in the game.
	 * 
	 * @return the number of moves
	 */
	public int getMoveCount() {
		return moveHistory.size();
	}

	/**
	 * Returns the number of rows of the board.
	 * 
	 * @return number of rows
	 */
	public int getRowSize() {
		return grid.length;
	}

	/**
	 * Returns the number of columns of the board.
	 * 
	 * @return number of columns
	 */
	public int getColSize() {
		return grid[0].length;
	}

	/**
	 * Returns the cell located at a given row and column.
	 * 
	 * @param row the given row
	 * @param col the given column
	 * @return the cell at the specified location
	 */
	public Cell getCell(int row, int col) {
		return grid[row][col];
	}

	/**
	 * Returns a list of all blocks on the board.
	 * 
	 * @return a list of all blocks
	 */
	public ArrayList<Block> getBlocks() {
		return blocks;
	}

	/**
	 * Returns true if the player has completed the puzzle by positioning a block
	 * over an exit, false otherwise.
	 * 
	 * @return true if the game is over
	 */
	public boolean isGameOver() {
		    if(block==null) {
		    	return false;
		    }
		    if(gameover==false) {//used for the case when we want to set our method to false even though it will return true
		    	gameover=true;
		    	return false;
		    }
			int r = block.getFirstRow();
			int c = block.getFirstCol();
			int l = block.getLength();
			Orientation or = block.getOrientation();
			if(or==HORIZONTAL) {
				for( int j = 0 ; j < l ; j++) {
					if(grid[r][c+j].isExit()) {
						return true;
					}
				
			}
				
			}
			else if (or == VERTICAL) {
				for( int j = 0 ; j < l ; j++) {
					if(grid[r+j][c].isExit()) {
						return true;
					}
				}
				}
	
		
		return false;
	}

	/**
	 * Moves the currently grabbed block by one cell in the given direction. A
	 * horizontal block is only allowed to move right and left and a vertical block
	 * is only allowed to move up and down. A block can only move over a cell that
	 * is a floor or exit and is not already occupied by another block. The method
	 * does nothing under any of the following conditions:
	 * <ul>
	 * <li>The game is over.</li>
	 * <li>No block is currently grabbed by the user.</li>
	 * <li>A block is currently grabbed by the user, but the block is not allowed to
	 * move in the given direction.</li>
	 * </ul>
	 * If none of the above conditions are meet, the method does the following:
	 * <ul>
	 * <li>Moves the block object by calling its move method.</li>
	 * <li>Sets the block for the grid cell that the block is being moved into.</li>
	 * <li>For the grid cell that the block is being moved out of, sets the block to
	 * null.</li>
	 * <li>Moves the currently grabbed cell by one cell in the same moved direction.
	 * The purpose of this is to make the currently grabbed cell move with the block
	 * as it is being dragged by the user.</li>
	 * <li>Adds the move to the end of the moveHistory list.</li>
	 * <li>Increment the count of total moves made in the game.</li>
	 * </ul>
	 * 
	 * @param dir the direction to move
	 */
	public void moveGrabbedBlock(Direction dir) {
		if((!isblockg)||isGameOver()||(isblockg&&((block.getOrientation()==VERTICAL)&&(dir==Direction.LEFT||dir==Direction.RIGHT)))||(isblockg&&(block.getOrientation()==HORIZONTAL)&&(dir==Direction.UP||dir==Direction.DOWN))) {
			return;
		}else {
			block.move(dir);
			
			int row = block.getFirstRow();
			int col = block.getFirstCol();
			int len = block.getLength();
			Orientation ori = block.getOrientation();
			grabrow=row;
		    grabcolumn=col;
			if(dir==Direction.UP) {// makes loop to iterate and set block to the desired direction
				if(canPlaceBlock(row, col)) {// checks if we can place block where we want to move 
			    for(int j =0 ; j < len ; j++){
			    	grid[grabrow+j][grabcolumn].setBlock(block);
			    }
			    grid[grabrow+len][grabcolumn]= new Cell(FLOOR,grabrow+len,grabcolumn);
			    Move x = new Move(block,dir);
				moveHistory.add(x);//adds new move to the moveHistory part of our code 
				}  
			else {
				block.setFirstRow(row+1);
			}
			}
			else if(dir==Direction.DOWN ) {
				if(canPlaceBlock(row+len-1, col)) {
				for(int j =0 ; j < len ; j++){
			    	grid[grabrow+j][grabcolumn].setBlock(block);
			    }
			    grid[grabrow-1][grabcolumn] = new Cell(FLOOR,grabrow-1,grabcolumn);
			    Move x = new Move(block,dir);
				moveHistory.add(x);
			
			    
				}else {
				block.setFirstRow(row-1);
			}
			}
			else if(dir == Direction.RIGHT){
				if(canPlaceBlock(row, col+len-1)) {
					
				
			    grid[row][grabcolumn-1].setBlock(block);
			    
			    for( int j = len-1 ; j >=0 ; j--) {
					grid[grabrow][grabcolumn+j].setBlock(block);
				}
			    grid[grabrow][grabcolumn-1] = new Cell(FLOOR,grabrow,grabcolumn-1);
			   
			    Move x = new Move(block,dir);
				moveHistory.add(x);
			
				} else {
		    	block.setFirstCol(col-1);
		    	
		    }
			}
			else if(dir == Direction.LEFT){
			    if(canPlaceBlock(row, col)) {
			    	
			    
			   for( int j = 0 ; j < len ;j ++) {
				   grid[grabrow][grabcolumn+j].setBlock(block);
			   }
			   grid[grabrow][grabcolumn+len] = new Cell(FLOOR,grabrow,grabcolumn+len);
			 
			   Move x = new Move(block,dir);
				moveHistory.add(x);
			    
			    }else {
				block.setFirstCol(col+1);
			}
			}
			
			
			
			
		}
			
		}
	

	/**
	 * Resets the state of the game back to the start, which includes the move
	 * count, the move history, and whether the game is over.The method calls the
	 * reset method of each block object. It also updates each grid cells by calling
	 * their setBlock method to either set a block if one is located over the cell
	 * or set null if no block is located over the cell.
	 */
	public void reset(){
		moveHistory = new ArrayList<Move>();
		if(isGameOver()) {
			gameover=false;
		}
		for(Block i : blocks) {
			i.reset();// resets all blocks 
		}
		releaseBlock();
		String[][] arr = Board.isgmaker(grid);// uses helper method which makes a 2d grip rep without any blocks 
		Cell[][] gridnew = GridUtil.createGrid(arr);
		Board board = new Board(gridnew, blocks);
	}


	/**
	 * Returns a list of all legal moves that can be made by any block on the
	 * current board. If the game is over there are no legal moves.
	 * 
	 * @return a list of legal moves
	 */
	public ArrayList<Move> getAllPossibleMoves() {
		if(isGameOver()) {
			return null;
		}else {
			ArrayList<Move> allpmoves = new ArrayList<Move>();
			for( Block i : blocks) {
				int row = i.getFirstRow();
				int col = i.getFirstCol();
				int len = i.getLength();
				if(i.getOrientation()==VERTICAL) {
					if(canPlaceBlock(row-1, col)) {
						Move x = new Move(i,Direction.UP);
						allpmoves.add(x);
						
					}if(canPlaceBlock(row+len, col)) {
						
						Move x = new Move(i,Direction.DOWN);
						allpmoves.add(x);
						
					}
				}else if(i.getOrientation()==HORIZONTAL) {
					if(canPlaceBlock(row, col-1)) {
						Move x = new Move(i,Direction.LEFT);
						allpmoves.add(x);
					}if(canPlaceBlock(row, col+len)) {
						Move x = new Move(i,Direction.RIGHT);
						allpmoves.add(x);
					}
					
					
				}

			
			}
			return allpmoves;
		}
		
	}

	/**
	 * Gets the list of all moves performed to get to the current position on the
	 * board.
	 * 
	 * @return a list of moves performed to get to the current position
	 */
	public ArrayList<Move> getMoveHistory() {
		return moveHistory;
	}

	/**
	 * EXTRA CREDIT 5 POINTS
	 * <p>
	 * This method is only used by the Solver.
	 * <p>
	 * Undo the previous move. The method gets the last move on the moveHistory list
	 * and performs the opposite actions of that move, which are the following:
	 * <ul>
	 * <li>grabs the moved block and calls moveGrabbedBlock passing the opposite
	 * direction</li>
	 * <li>decreases the total move count by two to undo the effect of calling
	 * moveGrabbedBlock twice</li>
	 * <li>if required, sets is game over to false</li>
	 * <li>removes the move from the moveHistory list</li>
	 * </ul>
	 * If the moveHistory list is empty this method does nothing.
	 */
	public void undoMove() {
		if( moveHistory.size() == 0 ) {
			return;
		}else {
			System.out.println("gg");
			Move m = moveHistory.get(moveHistory.size()-1);
			System.out.println(m);
			Block b = m.getBlock();
			Direction d = m.getDirection();
			System.out.println(d);
			grabBlockAtCell(b.getFirstCol(),b.getFirstRow());
			if(isGameOver()) {
				gameover=false;
				
			}
			
			if( d == RIGHT) {
				moveGrabbedBlock(LEFT);
				System.out.println("g");
			}else if ( d == LEFT) {
				
				moveGrabbedBlock(RIGHT);
			}else if ( d == UP) {
				moveGrabbedBlock(DOWN);
			}else if ( d== DOWN) {
				moveGrabbedBlock(UP);
			}
			moveHistory.remove(moveHistory.size()-1);
			moveHistory.remove(moveHistory.size()-1);
			
		}
		
	}
	
	@Override
	public String toString() {
		StringBuffer buff = new StringBuffer();
		boolean first = true;
		for (Cell row[] : grid) {
			if (!first) {
				buff.append("\n");
			} else {
				first = false;
			}
			for (Cell cell : row) {
				buff.append(cell.toString());
				buff.append(" ");
			}
		}
		return buff.toString();
	}

	//Some testcases I used while testing if code works
	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("Making board with testGrid1."); 
		Board board = new Board(testDescription1); 
		System.out.println(board.toString());
		board.grabBlockAtCell(2, 2); 
		board.moveGrabbedBlock(LEFT); 
		System.out.println("After moving block right one time game over is " 
		+ board.isGameOver() + ", expected is false."); 
		System.out.println(board.toString()); 
		System.out.println(); 
		 
		board.moveGrabbedBlock(RIGHT); 
		System.out.println(blocks);
		System.out.println("After moving block right two times game over is " 
		+ board.isGameOver() + ", expected is true."); 
		System.out.println(board.toString());
		System.out.println(board.getAllPossibleMoves());
		//board.moveGrabbedBlock(RIGHT); 
		
		System.out.println("After moving block right one time game over is " 
				+ board.isGameOver() + ", expected is false."); 
		System.out.println(board.toString());
		//board.reset();
		System.out.println(board.isGameOver());
		System.out.println(board.toString());
		System.out.println("After moving block right one time game over is " 
				+ board.isGameOver() + ", expected is false."); 
		//board.reset();
		System.out.println(board.toString());
		board.grabBlockAtCell(2, 2); 
		board.moveGrabbedBlock(RIGHT);
		System.out.println(board.toString());
		System.out.println(board.getMoveCount());
		board.reset();
		System.out.println(board.toString());
		
		
		//board.moveGrabbedBlock(RIGHT);
		/*System.out.println(board.toString());
		System.out.println(board.getMoveCount());
		System.out.println(board.getMoveHistory());
		board.undoMove();
		System.out.println(board.toString());
		board.undoMove();
		System.out.println(board.toString());
		System.out.println(board.getMoveHistory());*/
		/*board.reset();
		System.out.println(board.getMoveCount());
		System.out.println(board.getMoveHistory());
		System.out.println(board.getAllPossibleMoves());
		System.out.println(board.toString());
		board.grabBlockAtCell(2, 2);
		board.moveGrabbedBlock(RIGHT);*/
	}
		/*
		System.out.println(board.getAllPossibleMoves());
		ArrayList<String[][]> x = DescriptionUtil.readBoardDescriptionsFromFile("/Users/akhileshnevatia/Desktop/games.txt");
		String[][] gg = x.get(0);
		testDescription1= gg;
		grid = GridUtil.createGrid(testDescription1);
		blocks = GridUtil.findBlocks(testDescription1);
		board = new Board(grid, blocks); 
		System.out.println(board.toString());
		board.grabBlockAtCell(2, 4); 
		board.moveGrabbedBlock(LEFT);
		System.out.println(board.toString());
		board.grabBlockAtCell(2, 4); 
		board.moveGrabbedBlock(LEFT);
		System.out.println(board.toString());
		board.grabBlockAtCell(3, 5); 
		board.moveGrabbedBlock(UP);
		System.out.println(board.toString());
		board.grabBlockAtCell(3, 5); 
		board.moveGrabbedBlock(UP);
		System.out.println(board.toString());
		board.grabBlockAtCell(3, 1); 
		board.moveGrabbedBlock(RIGHT);
		board.grabBlockAtCell(3, 2); 
		board.moveGrabbedBlock(RIGHT);
		System.out.println(board.toString());
		board.grabBlockAtCell(3, 3); 
		board.moveGrabbedBlock(RIGHT);
		System.out.println(board.toString());
		board.grabBlockAtCell(3, 4); 
		board.moveGrabbedBlock(RIGHT);
		System.out.println(board.toString());
		System.out.println(board.isGameOver());
		board.reset();
		System.out.println(board.toString());
		board.grabBlockAtCell(3, 1); 
		board.moveGrabbedBlock(LEFT);
		System.out.println(board.toString());
		board.grabBlockAtCell(5, 2); 
		board.moveGrabbedBlock(DOWN);
		System.out.println(board.toString());
		
		
		
		}*/
	
	
	

}
