package hw4;

import java.util.Arrays;

import api.Card;
import api.Hand;




/**
 * @author akhileshnevatia
 * Evaluator for a generalized full house.  The number of required
 * cards is equal to the hand size.  If the hand size is an odd number
 * n, then there must be (n / 2) + 1 cards of the matching rank and the
 * remaining (n / 2) cards must be of matching rank. In this case, when constructing
 * a hand, the larger group must be listed first even if of lower rank
 * than the smaller group</strong> (e.g. as [3 3 3 5 5] rather than [5 5 3 3 3]).
 * If the hand size is even, then half the cards must be of matching 
 * rank and the remaining half of matching rank.  Any group of cards,
 * all of which are the same rank, always satisfies this
 * evaluator.
 * 
 * The name of this evaluator is "Full House".
 */
//Note: You must edit this declaration to extend AbstractEvaluator
//or to extend some other class that extends AbstractEvaluator
public class FullHouseEvaluator extends AbstractEvaluator
{   
	
	/*
	 * Stores length of group 1 elements in all cards
	 */
	private int group1;
	
	/*
	 * Stores the length of group 2 elements in all cards
	 */
	private int group2;
	
	/**
	 * checks seperately if elements in group 1 index and group index 2 are equal
	 * @param group1
	 * @param group2
	 * @param main
	 * @return boolean 
	 */
	private boolean evall(int group1 , int group2 , Card[] main) {
		for(int i =0 ; i < group1-1 ; i ++) {
			if(main[i].getRank()==main[i+1].getRank()) {
				continue;
			}else {
				return false;
			}
		}
	   for(int j = group1 ; j <main.length-1 ; j ++ ) {
		   if(main[j].getRank()==main[j+1].getRank()) {
			   continue;
		   }else {
			   return false;
		   }
	    }
	   return true;
			
		}
		
		
	
  /**
   * Constructs the evaluator.
   * @param ranking
   *   ranking of this hand
   * @param handSize
   *   number of cards in a hand
   */
  public FullHouseEvaluator(int ranking, int handSize)
  {
	  super(ranking,handSize);
  }


public String getName() {
	return "Full House";
}



@Override
/**
 * Only case where create hand constructor is changed as we want bigger group of numbers first 
 */
public Hand createHand(Card[] allCards, int[] subset) {
	if(this.canSatisfy(allCards)) { 
		if(group2>group1) { // only if second group is bigger than 1st group we need to switch position of cards in constructor
			int count =0; // counter in loop
			Card[] ac = new Card[allCards.length];
			for( int i =group1 ; i < allCards.length ; i ++ ) {
				ac[count] = allCards[i];
				count++; // starts adding the group 2 elements first by looping
			}
			for( int j =0 ; j < group1 ; j++ ) {
				ac[count] = allCards[j]; // then goes on to add the group 1 elements 
				count++;
			}
			
			allCards = Arrays.copyOf(ac, ac.length); // stores Allcards as copy of our new array of full length
		}
		
		
	}
	
 Hand h = new Hand(allCards, null,this); // makes hand
 return h;
	
	
}


public boolean canSatisfy(Card[] mainCards) {
	int len =  mainCards.length; 
	boolean condition = false;
	// makes 2 groups based on length
		group1= len/2;  
		group2= len-group1; 
		condition = evall(group1 , group2 , mainCards); // stores value returned by method
		if(condition==false) { // if condition still false calls method
			group2= len/2;
			group1= len-group2;
			condition = evall(group1 , group2 , mainCards);
	    }
	return condition;
}


}
