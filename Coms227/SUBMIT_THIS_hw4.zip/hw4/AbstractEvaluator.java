package hw4;
import java.util.ArrayList;

import api.Card;
import api.Hand;
import api.IEvaluator;
import util.SubsetFinder;

/**
 * @author akhileshnevatia
 * The class AbstractEvaluator includes common code for all evaluator types.
 * 
 * TODO: Expand this comment with an explanation of how your class hierarchy
 * is organized.
 */


/**EXPLAINING INHERITANCE USED :
 * The top of my UML code had the interface IEvaluator 
 * My AbstractClass Evaluator Class then implements the IEvaluator
 * I made an abstract class ofAKind which put together common methods in OnePairEvaluator, Three of A kind and Four of A kind
 * OfAKind then extends the AbstractEvaluator and then the three other classes induvidually extend ofAKindClass
 * CatchAllEvaluator , PrimeEvaluator and FullHouseEvaluator induvidually extend AbstractClass Evaluator without any new Abstarct Clases inbetween 
 * StraightFlushEvaluator and StraightEvaluator also extend AbstarctClass evaluator and the canSatisfy method od straightflush uses the one in straight
 */

public abstract class AbstractEvaluator implements IEvaluator
{   /**
     * Stores the ranking inputted by user
     */
	private int ranking ; 
	/**
	 * Stores the handSize
	 */
	private int handSize; 
	
	public int getRanking() {
		return this.ranking;
	}

	
	public int handSize() {
		return this.handSize;
	}
	
	public int cardsRequired() {
		return this.handSize();
	}
	
	protected AbstractEvaluator(int ranking, int handSize) {
		this.handSize = handSize;
		this.ranking = ranking;
		
		
	}
	
	
	 private Card[] subsetToCardList( int[] x , Card[] allCards) {
		  Card[] arr = new Card[x.length];
		  for(int i =0 ; i < x.length ; i ++) {
			  arr[i] = allCards[x[i]];
		  }
		  
		  return arr ; 
		  
	  }
	   
		
		

		
		public Hand createHand(Card[] allCards, int[] subset) {
			if(allCards.length<this.handSize() || ( subset.length != this.cardsRequired())) {
				return null;
			}else {
				Card[] arr = subsetToCardList( subset , allCards);
				if(canSatisfy(arr)) {
					Card[] mainCards = arr; // mainCards array assigned as arr
					// now we need to make a list of the sidecards 
				   int 	sideCount = allCards.length-subset.length; 
				   int[] side = new int[sideCount]; // makes a new sidecard array used to store sidecards
				   int counter = 0; // used as index counter for sidecard 
				   int count = 0 ; // keeps a track if any of the allcard element matches the main card element
				   for(int i =0 ; i < allCards.length ; i ++ ) {
					   for( int j : subset) {
						   if( i == j) { 
							   count++; // increaments count indication element in allCard is a part of the main
							   continue;
						   }
					   }
					   if( count==0) {// if the element in allcard isnt a main element count is 0
						   side[counter] = i ; // side is assigned the index 
						   counter++; // counter is updated 
					   }else {
						   count=0; // count is set back to 0 otherwise
					  }
					   
				   
				   }
				   Card[] arr2 = subsetToCardList( side , allCards); // helper method called to convert sidecard index to sidecards
				   Hand h = new Hand(mainCards,arr2,this); // new hand is created and returned 
				   return h;
				   
				   
				   
				   }else {
					return null ; 
				}
				
				
			}
			
		}
		
		
		public boolean canSubsetSatisfy(Card[] allCards) { 
			if (allCards.length >= this.cardsRequired()){
				ArrayList<int[]> subsets = SubsetFinder.findSubsets(allCards.length, this.cardsRequired());
				for(int[] i : subsets) {
					Card[] arr = subsetToCardList( i , allCards);
					if(this.canSatisfy(arr)) {
						return true ;
					}
					
				}
			}
			return false;
			
			
		}
		
		
		public Hand getBestHand(Card[] allCards) { 
			if( this.canSatisfy(allCards)) {
				Hand h = new Hand (allCards ,null , this);
				return h;
			}else {
				return null;
			}
		}
		
		
		
	
}
