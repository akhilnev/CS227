package hw4;

import api.Card;


/**
 * @author akhileshnevatia
 * Evaluator for a hand in which the rank of each card is a prime number.
 * The number of cards required is equal to the hand size. 
 * 
 * The name of this evaluator is "All Primes".
 */
//Note: You must edit this declaration to extend AbstractEvaluator
//or to extend some other class that extends AbstractEvaluator
public class AllPrimesEvaluator extends AbstractEvaluator
{
	
  /**
   * Constructs the evaluator.
   * @param ranking
   *   ranking of this hand
   * @param handSize
   *   number of cards in a hand
   */
  public AllPrimesEvaluator(int ranking, int handSize) 
  {
	super(ranking,handSize);
   
  }
/**
 * takes in input and returns true if prime and false if not 
 * @param n
 * @return boolean 
 */
  private boolean isPrime(int n)
  {
      if (n <= 1) {
    	  return false;
    	  
      }
      for (int i = 2; i < n; i++) {
          if (n % i == 0)
              return false;
      }

      return true;
  }


public String getName() {
	return "All Primes ";
}



public boolean canSatisfy(Card[] mainCards) {
	for(int i =0 ; i < mainCards.length ; i++) {
		if(isPrime(mainCards[i].getRank())) { // checks if all elements in the list are prime or not 
			continue;
		}else {
			return false;
		}
	}
	return true;
}


  
  
  
  
}
