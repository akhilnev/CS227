package hw4;



import api.Card;
import api.Hand;


/**
 * 
 * @author akhileshnevatia
 * Extra Abstarct Class linking OnePair , Three of A Kind , Four of A Kind 
 */

public abstract class ofAkind extends AbstractEvaluator {
	 
	 
	 
	 public ofAkind(int ranking, int handSize) {
		 super(ranking,handSize);
		 
		 
	 }
	 
	 
	@Override
	public Hand getBestHand(Card[] allCards) { // common for all of a kind checking of multiple classes 
		int len = this.cardsRequired();
		Card[] main = new Card[len];
		int k = 0 ;
		for( int i =0 ; i< allCards.length -len ; i ++) {
			k = i ;
			for( int j =0 ; j< this.cardsRequired(); j ++) {
				main[j] = allCards[k];
				k++; // creates group of main cards based on cardaRequired
			}
			  k = i; // uses the initial position of  
		   
		if(this.canSatisfy(main)) { // checks if main subset satisfies the method
			Card[] side = new Card[allCards.length -len]; 
			int count = 0 ;
			//Adds the other elements except the main to the all cards list to get sidecard Array
			for ( int j = 0 ; j < k ; j ++) {
				side[count] = allCards[j];
				count++; 
			}
			for ( int j = k + len ; j  <allCards.length ; j ++ ) {
				side[count] = allCards[j];
				count++;
				
			}
			
			Hand h = new Hand( main , side  , this); // makes new hand
			return h ;
			
		}
		}
		
		return null;
			
			
		}
	
	
	

}
